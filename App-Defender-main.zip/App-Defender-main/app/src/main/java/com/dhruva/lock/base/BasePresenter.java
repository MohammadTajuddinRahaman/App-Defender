package com.dhruva.lock.base;


public interface BasePresenter {
}
