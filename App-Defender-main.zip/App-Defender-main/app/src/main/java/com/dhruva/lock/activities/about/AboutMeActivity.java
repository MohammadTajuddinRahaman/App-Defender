package com.dhruva.lock.activities.about;

import android.os.Bundle;

import com.dhruva.lock.R;
import com.dhruva.lock.base.BaseActivity;



public class AboutMeActivity extends BaseActivity {
    @Override
    public int getLayoutId() {
        return R.layout.activity_about_me;
    }

    @Override
    protected void initViews(Bundle savedInstanceState) {

    }

    @Override
    protected void initData() {

    }

    @Override
    protected void initAction() {

    }
}
