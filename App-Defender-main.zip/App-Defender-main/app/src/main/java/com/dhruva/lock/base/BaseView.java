package com.dhruva.lock.base;


public interface BaseView<T extends BasePresenter> {
}
